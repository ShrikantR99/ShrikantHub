function SayHello(name:string, age:number):void
{
    //new way in TS
    console.log(`Hello${name}`);
    console.log(`${name}is${age}year old`);
}

SayHello("Shrikant",23)