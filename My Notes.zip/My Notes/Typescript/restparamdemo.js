"use strict";
//rest patamerters--> here read the function
function DrawPolygon(...points) {
    console.log(`Polygon draw with  ${points.length} points`);
    //iterate the points
    points.forEach(p => console.log(p));
}
DrawPolygon();
DrawPolygon(1, 2, 3, 4, 5);
DrawPolygon(1);
DrawPolygon();
DrawPolygon(1, 2);
//default value for the function args
// function DrawPolygon(point1:number=0,...points:number[]):void
// {
//     console.log(`Polygon draw with  ${points.length} points`);
//     //iterate the points
//     points.forEach(p=>console.log(p));
// }
// DrawPolygon();
// DrawPolygon(1,2,3,4,5);
// DrawPolygon(1);
// DrawPolygon();
// DrawPolygon(1,2);
