//spread operaters--> here call the function
function Print(name1: string, name2: string): void {
    console.log(`Name1: ${name1}`);
    console.log(`Name2: ${name2}`);
}
Print("shrikant", "rk");