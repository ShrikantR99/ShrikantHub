"use strict";
//spread operaters--> here call the function
function Print(name1, name2) {
    console.log(`Name1: ${name1}`);
    console.log(`Name2: ${name2}`);
}
Print("shrikant", "rk");
