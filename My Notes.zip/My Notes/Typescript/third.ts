function Do(): string {
    n = 10
}
Do();