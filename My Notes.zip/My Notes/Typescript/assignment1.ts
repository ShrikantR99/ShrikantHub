//write TS function which takes as number an argument and return boolean. The function must return true with number and is prime no. false otherwise.

function PrimeNumber(num: number) {
    if (num <= 1)
        return false;
    if (num == 2)
        return true;
    for (let i: number = 2; i <= num / 2; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

console.log(PrimeNumber(7))
console.log(PrimeNumber(30))




// function test_prime(n)
// {

//   if (n===1)
//   {
//     return false;
//   }
//   else if(n === 2)
//   {
//     return true;
//   }else
//   {
//     for(var x = 2; x < n; x++)
//     {
//       if(n % x === 0)
//       {
//         return false;
//       }
//     }
//     return true;
//   }
// }

// console.log(test_prime(4));