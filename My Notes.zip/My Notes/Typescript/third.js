"use strict";
function Do() {
    n = 10;
}
Do();
