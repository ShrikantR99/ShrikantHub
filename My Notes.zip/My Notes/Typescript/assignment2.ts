function concatStringNumber(name:string,age:number):string
{
    // let result:string=(`${name}${age}`)
    //return result;
    return `${name}${age}`
}

console.log(concatStringNumber("Shrikant",23)