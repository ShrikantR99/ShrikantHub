"use strict";
function circle(rad) {
    let area = Math.PI * rad * rad;
    let circum = 2 * Math.PI * rad;
    return [area, circum];
}
console.log(circle(5));
