"use strict";
function concatStringNumber(name, age) {
    // let result:string=(`${name}${age}`)
    //return result;
    return `${name}${age}`;
}
console.log(concatStringNumber("Shrikant", 23));
