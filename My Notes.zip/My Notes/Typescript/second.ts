// const Compute=(x:number,y:number)=>(x+y);

// function ComputeSqure(num:number):number
// {
//     return (num*num);
// }
// let addresult=Compute(10,20);
// let squreresult=ComputeSqure(50);
// console.log(`Addition results ${addresult}`);
// console.log(`squre results ${squreresult}`);



let empid:any = 20;
console.log(empid.toUpperCase());
console.log('hello');