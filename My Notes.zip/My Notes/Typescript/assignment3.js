"use strict";
function argsSum(a, b, ...k) {
    var sum = 0;
    for (var i = 0; i < k.length; i++) {
        sum += k[i];
    }
    return sum + a + b;
}
console.log(argsSum(1, 2, 3, 4));
