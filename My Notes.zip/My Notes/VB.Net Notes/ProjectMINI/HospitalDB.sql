
create database HospitalDB

use HospitalDB

Create table doctor_info
(
	id integer primary key identity(1000,1),
	name varchar(50) not null,
	contactno varchar(50) unique not null,
	specialization varchar(50) not null,
	visit_type varchar(50) not null
)

Select * from doctor_info

CREATE PROCEDURE insert_data
@name varchar(50),
@contact varchar(10),
@spl varchar(50),
@visit varchar(50)
AS
BEGIN
insert into doctor_info(name,contactno,specialization,visit_type) values(@name,@contact,@spl,@visit)
END

CREATE PROCEDURE fetch_data
AS
BEGIN
Select * from doctor_info
END

CREATE PROCEDURE delete_data_by_id @id int
AS
BEGIN
Delete from doctor_info where id = @id
END


Drop table doctor_info