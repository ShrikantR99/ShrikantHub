-------------------------SQL QUERY DAY 5 ASSIGNMENT-----------------------

/*1. Write a procedure to insert data in Patient and PatientAddress tables using input parameters [PatientID is an Identity column in Patient table and PatientAddress table is related to Patient table] */
CREATE TABLE Patient1
(     PatientID INT PRIMARY KEY ,
      PatientName VARCHAR(30),
      Gender VARCHAR(1),
)
CREATE TABLE PatientAddr
(
       PatientID INT REFERENCES dbo.patient1(patientid),
       PatientAddress VARCHAR(30)
)


CREATE PROCEDURE insert_new_patients
(
    @PatientID INT,  
    @PatientName VARCHAR(50),    
    @Gender VARCHAR(1),
    @PatientAddress VARCHAR(100)
)
AS
BEGIN
    INSERT INTO Patient1 VALUES
        (@PatientID,@PatientName,@Gender);
    PRINT 'Record Succesfully Inserted!'
END;

EXECUTE dbo.insert_new_patient1 3,'Shrikant','M','Ravalukedari'

SELECT * FROM Patient1;


/*2. An input string representing passenger data comes in a below format to a procedure. Extract the data from the string and store in a temporary table. String format: �[P9001,John Roy,Male,12-Jan-2009]�*/

CREATE SCHEMA Passengers
CREATE TABLE PassengerData1
(
PassengerID int,
PassengerName VARCHAR(30),
Gender VARCHAR(5),
PDate Date
)

INSERT INTO PassengerData1 Values('1','Shrikant ','Male','22-feb-2002')
SELECT * FROM PassengerData1;
CREATE PROCEDURE sp_get_name_from_businessentityid
(
    @PID INT,
    @PassName  VARCHAR(70) OUTPUT
)AS
BEGIN
    PRINT 'Finding Person....';
    SELECT @PassName = PassengerName
        FROM PassengerData1 WHERE PassengerID = @PID;
    PRINT 'Found Person...';
END;


DECLARE @PH VARCHAR(70);
EXEC dbo.sp_get_name_from_businessentityid 1,@PH OUTPUT;
PRINT @PH;


SELECT PassengerID ,PassengerName,Gender,PDate
INTO #TempLocationCol1
FROM PassengerData
GO
SELECT * FROM #TempLocationCol1


/* 3. Modify the Day 5 - Lab 2 to validate the below

   1. No duplicate entry for a passenger must be attempted to insert in table
   2. The Age of the passenger must be between 6 to 90 */

CREATE TABLE #Table
(
ID varchar(10) PRIMARY KEY,
name varchar(15),
gender varchar(10),
dob DATE check( YEAR(GETDATE())  - year(dob) between 6 and 90)  
)

SELECT * FROM #Table

create procedure pro1
(
@String varchar(50),
@one varchar(10)=null,
@two varchar(10)=null,
@three varchar(10)=null,
@four varchar(15)=null
)as
begin
set @one =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@one+',')+1,len(@String))

set @two =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@two+',')+1,len(@String))

set @three =substring(@String,0,PATINDEX('%,%',@String))
set @String =substring(@String,len(@three+',')+1,len(@String))

set @four=@String


insert into #Table(ID,name,gender,dob) values (@one,@two,@three,@four)

select * from #Table
PRINT @one;
PRINT @two;
PRINT @three;
PRINT @four;
print 'inserted!'
end;


EXECUTE Pro1 'P101,Shrikant ,Male,22-Feb-2002';