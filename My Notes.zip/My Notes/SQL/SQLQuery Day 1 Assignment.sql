----DATABASE Name----
USE ShopperStoreDb28;

/* SQL Query Day 1 Assignment */

--ProductCategory Table
CREATE SCHEMA Production;
CREATE TABLE Production.ProductCategory
(
ProductCategoryID INT PRIMARY KEY IDENTITY(1001,1),                                            
ProductCategoryName VARCHAR(50) NOT NULL,
);




--Country Table
CREATE SCHEMA Sales;
CREATE TABLE Sales.Country
(
CountryID INT PRIMARY KEY IDENTITY(1001,1),                                            
CountryName VARCHAR(50) NOT NULL,
);




--Department Table
CREATE SCHEMA HumanResources;
CREATE TABLE HumanResources.Department
(
DepartmentID INT PRIMARY KEY IDENTITY(1001,1),                                        
DepartmentName VARCHAR(50) NOT NULL,
);




--Person Table
CREATE SCHEMA Person;
CREATE TABLE Person.Person
(
PersonID INT PRIMARY KEY IDENTITY(1001,1),
Title VARCHAR(50),
FirstName VARCHAR(50) NOT NULL,
MiddleName VARCHAR(50) NOT NULL,
LastName VARCHAR(50) NOT NULL,
Gender VARCHAR(1) CHECK(Gender IN('M','F','O','U'))NOT NULL,
ModifiedDate DATETIME NOT NULL,                                                    
);




--Territory Table
CREATE TABLE Sales.Territory
(
TerritoryID INT PRIMARY KEY IDENTITY(1001,1),    
CountryID INT REFERENCES Sales.Country(CountryID),
TerritoryName VARCHAR(50) NOT NULL,
);




--Customer Table
CREATE TABLE Sales.Customer
(
CustomerID INT PRIMARY KEY IDENTITY(1001,1),
CustomerGrade VARCHAR(5) NOT NULL,
PersonID INT REFERENCES  Person.Person(PersonID),
TerritoryID INT REFERENCES Sales.Territory(TerritoryID),
);




--Employee Table
CREATE TABLE HumanResources.Employee
(
EmployeeID INT PRIMARY KEY IDENTITY(1001,1),
Designation VARCHAR(20) NOT NULL,
ManagerID INT NOT NULL,
DateOfJoining DATE NOT NULL,
PersonID INT REFERENCES  Person.Person(PersonID),
DepartmentID INT REFERENCES  HumanResources.Department(DepartmentID),
);



--SalesOrderHeader Table
CREATE TABLE Sales.SalesOrderHeader
(
SalesOrderHeaderID INT PRIMARY KEY IDENTITY(1001,1),
OrderDate DATETIME NOT NULL,
CustomerID INT REFERENCES Sales.Customer(CustomerID),
SalesPersonID INT NOT NULL
);



--ProductSubCategory Table
CREATE TABLE Production.ProductSubCategory
(
ProductSubCategoryID INT PRIMARY KEY IDENTITY(1001,1),              
ProductSubCategoryName VARCHAR(50) NOT NULL,
ProductCategoryID INT REFERENCES Production.ProductCategory(ProductCategoryID),
);



--Product Table
CREATE TABLE Production.Product
(
ProductID INT PRIMARY KEY IDENTITY(1001,1),                     
ProductName VARCHAR(50) NOT NULL,
ProductCost MONEY NOT NULL,
QuantityInStock VARCHAR(10) NOT NULL,
ProductSubCategoryID INT REFERENCES Production.ProductSubCategory(ProductSubCategoryID),
);



--SalesOrderDetail Table
CREATE TABLE Sales.SalesOrderDetail
(
SalesOrderDetailID INT PRIMARY KEY IDENTITY(1001,1),    
SalesOrderHeaderID INT REFERENCES Sales.SalesOrderHeader(SalesOrderHeaderID),
ProductID INT REFERENCES Production.Product(ProductID),
OrderQuantity VARCHAR(10) NOT NULL
);
