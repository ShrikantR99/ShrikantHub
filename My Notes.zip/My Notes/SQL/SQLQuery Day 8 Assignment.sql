----------------SQL QUERY DAY 8 ASSIGNMENT--------------------------------------

/*1. Document your understanding on Query plan*/

/*A query plan is a set of steps that the database management system executes in order to complete the query.  
The reason we have query plans is that the SQL we write may declare our intentions, but it does not tell SQL 
the exact logic flow to use.  The query optimizer determines that.The result of that is the query plan.

Since SQL is a declarative language, we tell SQL what to do, but not how to do it. This means, many of the 
mechanics and in�s and out�s are lets to the DBMS. It gets to choose whether to use an index or just scan a table.

In SQL Server a query plan is called an execution plan.*/

/*2. Document your understanding on different types of Scans while reading from a table*/

/*Types of Scans:
1. Index Scan:
The Index Scan operator is used to read all or most data from a nonclustered index. In combination with a Top operator, 
an Index Scan can also be used to read the first few rows according to the innate order of a nonclustered index, or to read 
just a few rows from a table when data order is irrelevant and the index used is the smallest available index.

The logic of the Index Scan operator itself is fairly simple, but the actual actions carried out can vary hugely depending
on the type of index being scanned. Most of this logic is carried out at the level of the storage engine.

2.Table Scan:

The Table Scan operator is used to read all or most data from a table that has no clustered index (also known as a heap table, 
or just as a heap). In combination with a Top operator, it can also be used to read just a few rows from a heap table when data 
order is irrelevant and there is no nonclustered index that covers all required columns.

The basic behavior of a Table Scan operator is very similar to that of the Index Scan operator when it chooses to do an IAM 
scan, but with a few very important differences. A heap table has no root, intermediate, and leaf level pages; it has data 
pages only. Each page read from the IAM is a data page and can be processed. But rows on a data page of a heap table can 
contain forwarding pointers, that cause out of order data access.
*/

/*3. Consider the below SalesPerson table

Name Year Sales

Sam 2010 20000

John 2010 30000

John 2010 15000

Sam 2011 70000

John 2011 89000

Sam 2011 12000

Calculate the overall sales for both the salespersons corresponding to the year values as shown below (Pivot)

Year Sam John

2010 20000 45000

2011 82000 89000
*/

CREATE TABLE SalesPerson  
(    
   Name varchar(45),    
   Year int,    
   Sales int    
)
DROP TABLE SalesPerson

INSERT INTO SalesPerson
VALUES ('Sam', 2010, 20000),
('John', 2010 ,30000),
('John', 2010 ,15000),
('Sam', 2011 ,70000),
('John', 2011, 89000),
('Sam', 2011, 12000)

SELECT * FROM SalesPerson

SELECT Year, Sam, John FROM     
(SELECT Name, Year, Sales FROM SalesPerson ) AS Tab1    
PIVOT    
(SUM(Sales) FOR Name IN (Sam,John)) AS Tab2    
ORDER BY Tab2.Year 


/*4. Document some Good and Bad practices while working with the below DB objects / commands

a. Tables
GOOD PRACTICE:

SELECT
  ci.name AS city_name,
  ci.district,
  co.name AS country_name,
  ci.population
FROM
  Country AS co
  INNER JOIN City AS ci ON (co.code = ci.countrycode)
WHERE
  (co.continent = 'africa') AND
  (ci.population BETWEEN 1000000 AND 1500000)
ORDER BY
  ci.population DESC
LIMIT 10;

BAD PRACTICE:

select
  City.name,
  District,
  Country.name,
  City.population
from
  Country
  inner join City on City.countrycode = Country.code
where
  continent = 'africa' and
  City.population between 1000000 and 1500000
order by
  City.population desc
limit 10;

Both queries will execute and return the same results, but the first one is much more readable. Issues with respect to the 
table aliasing in the second query:
1) It is unclear without looking at the table structure whether District and continent are fields of the city or the country 
table.
2) The full table name needs to be specified for every field that would otherwise be ambiguous. This clutters the query and 
thus makes it less readable.
3) if I ever need to change the name of the table I am querying, I have to change it in all places instead of just in the from 
clause. A good example is when I was writing this article: I used lower case c�s for the country and city table names. So after
writing the whole statement I had to go back in and change that lowercase c to an uppercase c in close to a dozen places, while 
in the first query I just needed to change it in one place.

b. Joins
GOOD PRACTICE:

1. Use the JOIN and ON Keywords
SELECT *
FROM customers
JOIN orders
ON customers.id = orders.customer_id;
SELECT *
FROM customers, orders
WHERE customers.id = orders.customer_id;

2. Choose Appropriate SQL JOIN Type like Inner,Left or Right Join.
3. Use Table Aliases
4. 4. Use Column Aliases

BAD PRACTICE:

1. It is less readable; this gets worse with complex SQL queries. We have to look closely to establish the tables 
that are being joined. We also have to find the join condition, which doesn�t have a standard ON keyword before it.
2.We cannot specify the JOIN type when using an implicit JOIN (e.g. FROM customers, orders). This can be a problem if
we need to use something beyond the standard INNER JOIN.
3. Defining a join condition in the WHERE clause can be very confusing, since this is not the clause�s typical use. 

c. Indexes
GOOD PRACTICE:

1. Understand how database design impacts SQL Server indexes
2. Create indexes for your workload requirements
3. Create indexes for the most heavily and frequently used queries
4. Use data sort order
5. Use foreign keys for your SQL Server index
6. Always create a clustered index before a non-clustered index

BAD PRACTICE:

1. Don�t index every column of the table.
2. Don�t create more than 7 indexes per table (clustered and non-clustered)
3. Don�t leave a table as Heap (create a clustered index).
4. Don�t create an index on every column involved in every foreign key
5. Don�t rebuild an index too frequently (monthly once is good enough)
6. Don�t create an index with more than 5 to 7 key columns
*/


