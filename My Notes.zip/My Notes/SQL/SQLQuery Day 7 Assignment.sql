----------------------SQL QUERY DAY 7 ASSIGNMENT---------------------

/* 1. Create a procedure that takes a string parameter. The input string may be a string or a numeric or NULL value. Convert the string to Integer. If it cannot be converted write an exception handling section to handle the appropriate error. If the string is converted to integer print Hello the input integer number of times */

CREATE PROCEDURE st_str (@String VARCHAR(50))
AS
BEGIN
	DECLARE @IntStr VARCHAR(30);
	
	BEGIN TRY
		SET @IntStr = CONVERT(int, @String);
		PRINT REPLICATE('Hello ', @IntStr)
	END TRY
	BEGIN CATCH
		IF ERROR_NUMBER() = 245
			PRINT 'The String cannot be converted to integer.'
	END CATCH
END;

EXEC st_str @String = 'This is String Parameter';
EXEC st_str @String = 7;

--DROP PROCEDURE st_str


/* 2. Create a temp table to represent employees. Design a user defined exception to handle the salary input less than 10000. */
CREATE TABLE Emp
(
EmpID INT PRIMARY KEY,
EmpName VARCHAR(50),
Salary MONEY
)



BEGIN TRY
    DECLARE @Salary INT;
    SET @Salary=5000
    IF @Salary<=0
        THROW 50001,'Salary cannot be 0 or negative',1
    ELSE IF @Salary>0 AND @Salary<10000
        THROW 50002, 'Salary Less than 10000',1
    ELSE
        THROW 50003, 'Salary Greater than 10000',1
END TRY
BEGIN CATCH
    PRINT ERROR_NUMBER();
     PRINT ERROR_MESSAGE();
END CATCH

/* 3. Write a cursor to fetch top 10 costliest products */
DECLARE @ProdID INT;
DECLARE @ProdName VARCHAR(50);
DECLARE @Col VARCHAR(10);
DECLARE @StdCost VARCHAR(10);
DECLARE cur_products CURSOR FOR
SELECT TOP 10
ProductID,
Name,Color,
StandardCost
FROM
Production.Product
ORDER BY StandardCost DESC;
OPEN cur_products;
FETCH NEXT FROM cur_products INTO @ProdID,@ProdName,@Col,@StdCost;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT '=======================================';
    PRINT CONCAT('Product ID: ' ,@ProdID);
    PRINT 'Product Name: ' + @ProdName;
    PRINT 'Color: ' + @Col;
    PRINT 'Standard Cost: ' + @StdCost;
    PRINT '=======================================';
    FETCH NEXT FROM cur_products INTO @ProdID,@ProdName,@Col,@StdCost;
END;
CLOSE cur_products;
DEALLOCATE cur_products;

/* 4. Document your understanding and possible solutions to Deadlock concept [Hint: You may explore online] */

/*
Deadlock:
-> A deadlock can occur in almost any situation where processes share resources. It can happen in any computing environment, 
but it is widespread in distributed systems, where multiple processes operate on different resources.

-> Let's Understanding it,
Consider there are two people Person1, Person2,
Person1 wants to access a resource C1, Person2 wants to access a resource C2 and both will be locked for the processing. After completing some respective task,
Person1 wants to access C2 and same thing goes for Person2, who wants to access C1. The problem here is, Person2 has not completed the process in C2. By then, 
Person1 has to wait for C2 to be ready. Also, it doesn't know when will the resource C2 will be active to perform task.
This is how Deadlock will be happens.

-> A deadlock occurs when 2 processes are competing for exclusive access to a resource but is unable to obtain exclusive access to it because the other process is preventing it. 
This results in a standoff where neither process can proceed. 

Prevention:
-> These deadlocks can be prevented by applying a timestamp for each resource access. Once the time is up, the next person can have access to that resource.
If C1 can be accessed only for 10 minutes, then both the person can access that resource during their respective time.
*/