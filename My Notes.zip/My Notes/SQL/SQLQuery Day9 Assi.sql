--que1
--Create Table
CREATE TABLE Employees 
( EmpID int NOT NULL PRIMARY KEY, Name varchar(255) NOT NULL,  
Address  varchar(255),Phone varchar(255),  Salary Money);

--Insert Values
INSERT INTO Employees (EmpID, Name, Address, Phone, Salary)VALUES
('1', 'Shrikant', 'Belgaum', '9878906543', '8000'),
('2', 'Paras', 'Jammu', '8990076543', '5000'),
('3', 'Rushi', 'mumbai', '7789945765', '7000'),
('4', 'Suksham', 'ladakh', '9789945760', '4000'),
('5', 'Sandeep', 'Jaipur', '7800541123', '5500');

SELECT * FROM Employees

/* The following query deals with the result set containing the most top paid and
least paid salary to an employee where OFFSET and FETCH works together to fetch the 
required rows from the table Employees */
SELECT Name, Address FROM Employees ORDER BY Salary DESC OFFSET 2 ROWS
FETCH NEXT 2 ROWS ONLY;


--que2
--Create Table
CREATE TABLE Employees1 
( EmpID int NOT NULL PRIMARY KEY, Name varchar(255) NOT NULL,  
Address  varchar(255),Phone varchar(255),  Salary Money);

--Insert Values
INSERT INTO Employees1 (EmpID, Name, Address, Phone, Salary)VALUES
('1', 'Shrikant', 'Belgaum', '9878906543', '8000'),
('2', 'Paras', 'Jammu', '8990076543', '5000'),
('3', 'Rushi', 'mumbai', '7789945765', '7000'),
('4', 'Suksham', 'ladakh', '9789945760', '4000'),
('5', 'Sandeep', 'Jaipur', '7800541123', '5500');

SELECT * FROM Employees1

SELECT Name, SUM(Salary)
FROM Employees1
GROUP BY ROLLUP(Name);

--CUBE 
select Name,EmpID, SUM(Salary) as 'total_salary_cube'
From employees1
GROUP BY CUBE(Name,EmpID);
