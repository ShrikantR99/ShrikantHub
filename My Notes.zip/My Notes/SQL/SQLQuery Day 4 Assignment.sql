----------------SQL QUERY DAY 4 ASSIGNMENT-------------------------------------
/* 1. The HumanResources.Employee table does not contain the employee names. Join that table to the Person.Person table on the BusinessEntityID column. Display the job title, birth date, first name, and last name. */
SELECT
BSC.JobTitle,BSC.BirthDate,
PER.FirstName,PER.LastName
FROM HumanResources.Employee AS BSC
JOIN Person.Person AS PER
ON BSC.BusinessEntityID=PER.BusinessEntityID


/* 2. The customer names also appear in the Person.Person table. Join the Sales.Customer table to the Person.Person table. The BusinessEntityID column in the Person.Person table matches the PersonID column in the Sales.Customer table. Display the CustomerID, StoreID, and TerritoryID columns along with the name columns. */
SELECT
SAC.CustomerID,SAC.StoreID,SAC.TerritoryID,
PER.FirstName,PER.LastName
FROM Sales.Customer AS SAC
JOIN Person.Person AS PER
ON SAC.PersonID=PER.BusinessEntityID


/* 3 . Write a query that joins the Sales.SalesOrderHeader table to the Sales. SalesPerson table. Join the BusinessEntityID column from the Sales.SalesPerson table to the SalesPersonID column in the Sales.SalesOrderHeader table. Display the SalesOrderID along with the SalesQuota and Bonus. */
SELECT
SAC.SalesOrderID,SSP.SalesQuota,SSP.Bonus
FROM Sales.SalesOrderHeader AS SAC
JOIN Sales. SalesPerson AS SSP
ON SAC.SalesPersonID=SSP.BusinessEntityID


/* 4 . The catalog description for each product is stored in the Production.ProductModel table. Display the columns that describe the product from the Production.Product table, such as the color and size along with the catalog description for each product. */
SELECT
PPP.Color,PPP.Size,PPM.CatalogDescription
FROM Production.Product AS [PPP]
JOIN
Production.ProductModel AS [PPM]
ON PPP.ProductModelID = PPM.ProductModelID

/* 5 . Write a query that displays the names of the customers along with the product names that they have purchased. Hint: Five tables will be required to write this query! */
SELECT PPP.FirstName,PPP.LastName,PPR.Name AS [ProductName]
FROM Production.Product PPR
LEFT OUTER JOIN Sales.SalesOrderDetail SOD
ON PPR.ProductID=SOD.ProductID
LEFT OUTER JOIN Sales.SalesOrderHeader SOH
ON SOH.SalesOrderID=SOD.SalesOrderID
LEFT OUTER JOIN Sales.Customer SAC
ON SAC.CustomerID=SOH.CustomerID
LEFT OUTER JOIN Person.Person PPP
ON PPP.BusinessEntityID=SAC.PersonID;


/* 6. Write a query that displays all the products along with the SalesOrderID even if an order has never been placed for that product. Join to the Sales.SalesOrderDetail table using the ProductID column. */
SELECT PPR.ProductID,PPR.Name,PPR.ListPrice,SOD.SalesOrderID
FROM Production.Product PPR
LEFT OUTER JOIN Sales.SalesOrderDetail SOD
ON PPR.ProductID=SOD.ProductID
LEFT OUTER JOIN Sales.SalesOrderHeader SOH
ON SOH.SalesOrderID=SOD.SalesOrderID


/* 7. The Sales.SalesOrderHeader table contains foreign keys to the Sales.CurrencyRate and Purchasing.ShipMethod tables. Write a query joining all three tables, making sure it contains all rows from Sales.SalesOrderHeader. Include the CurrencyRateID, AverageRate, SalesOrderID, and ShipBase columns. */
SELECT SOH.*,CUR.CurrencyRateID, CUR.AverageRate, SOH.SalesOrderID, PUS.ShipBase
FROM Purchasing.ShipMethod PUS
RIGHT OUTER JOIN Sales.SalesOrderHeader SOH
ON PUS.ShipMethodID=SOH.ShipMethodID
LEFT OUTER JOIN Sales.CurrencyRate CUR
ON SOH.CurrencyRateID=CUR.CurrencyRateID


/* 8. Get all the order details to gererate a report that displays, OrderID, OrderNumber, OrderDate, Shipping Date and the product names, subcategory and category which are the part of that order and include the name of customer who has placed the order as well as the name of territory and country from where order has been placed [Hint: Identify the correct set of related tables] */
SELECT SOH.SalesOrderID,SOH.SalesOrderNumber,PPR.Name,SOH.OrderDate,SOH.ShipDate,
PSC.Name AS [SubCatName],PPC.Name AS [CategoryName],
PPP.FirstName,PPP.LastName,SST.Name AS [Region],PCR.Name AS [Country]
FROM Sales.SalesOrderHeader SOH
LEFT OUTER JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID=SOD.SalesOrderID
LEFT OUTER JOIN Production.Product PPR
ON PPR.ProductID=SOD.ProductID
LEFT OUTER JOIN Production.ProductSubcategory PSC
ON PSC.ProductSubcategoryID=PPR.ProductSubcategoryID
LEFT OUTER JOIN Production.ProductCategory PPC
ON PPC.ProductCategoryID=PSC.ProductCategoryID
JOIN Sales.Customer SAC
ON SAC.CustomerID=SOH.CustomerID
JOIN Person.Person PPP
ON PPP.BusinessEntityID=SAC.PersonID
JOIN Sales.SalesTerritory SST
ON SST.TerritoryID=SOH.TerritoryID
JOIN Person.CountryRegion PCR
ON PCR.CountryRegionCode=SST.CountryRegionCode;


/* 9. Get the Youngest Employee */
SELECT FirstName,LastName
FROM Person.Person
WHERE BusinessEntityID=
(
SELECT BusinessEntityID FROM
(
SELECT BusinessEntityID,NationalIDNumber,JobTitle,LoginID,BirthDate,Gender,ModifiedDate,
DENSE_RANK()OVER(ORDER BY BirthDate DESC) AS [Rank]
FROM HumanResources.Employee
)a
WHERE Rank=1)


/* 10.  Create a temp. table and copy the data form Production.Product table (only red colored products) in the temp. table [Hint: use subquery] */
CREATE TABLE Products
(
    ProdID INT,
    ProdName VARCHAR(50),
    Color VARCHAR(20),
    StdCost Money,
    ProdSubCatgID INT
);


INSERT INTO Products
SELECT ProductID,Name,Color,StandardCost,ProductSubcategoryID
FROM Production.Product WHERE Color='Red'



SELECT * FROM Products; 