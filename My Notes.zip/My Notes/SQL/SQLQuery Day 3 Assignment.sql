------------SQL QUERY DAY 3 ASSIGNMENT-----------------------

/* 1. Write a query to determine the number of customers in the Sales.Customer table. */
SELECT COUNT(*) AS [Number Of Customers]
FROM Sales.Customer

/* 2. Write a query using the Production.Product table that displays the minimum, maximum, and average ListPrice. */
SELECT MIN(ListPrice) AS [Minimum], 
MAX(ListPrice) AS [Maximum] ,
AVG(ListPrice) AS  [Average]
FROM Production.Product

/* 3. Write a query that shows the total number of items ordered for each product. Use the Sales.SalesOrderDetail table to write the query. */
SELECT ProductID, SUM(OrderQty) AS [No Of Items]
FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY ProductID

/* 4. Write a query using the Sales.SalesOrderDetail table that displays a count of the detail lines for each SalesOrderID. */
SELECT SalesOrderID,SUM(LineTotal) AS [Detail Count]
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID

/* 5. Write a query using the Production.Product table that lists a count of the products in each product line. */
SELECT ProductLine,COUNT(ProductLine) AS [ProductCount]
FROM Production.Product
GROUP BY ProductLine

/* 6. Write a query that displays the count of orders placed by year for each customer using the Sales.SalesOrderHeader table. */
SELECT CustomerID,YEAR (OrderDate) AS [Year],COUNT (SalesOrderID) AS [Orders] 
FROM Sales.SalesOrderHeader
GROUP BY CustomerID,YEAR (OrderDate)
ORDER BY CustomerID

/* 7. Write a query that creates a sum of the LineTotal in the Sales.SalesOrderDetail table grouped by the SalesOrderID.Include only those rows where the sum exceeds 1,000. */
SELECT * FROM
(
SELECT SalesOrderID,SUM(LineTotal) AS [Total]
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID
)t
WHERE Total>1000

/* 8. Write a query that groups the products by ProductModelID along with a count. Display the rows that have a count that equals 1. */
SELECT * FROM
(
SELECT ProductModelID,COUNT(ProductID)AS [Products]
FROM Production.Product
GROUP BY ProductModelID
)a
WHERE[Products]=1

/* 9. Write a query using the Sales.SalesOrderHeader, Sales.SalesOrderDetail, and Production.Product tables to display the total sum of products by ProductID and OrderDate. */
SELECT PRD.ProductID, SOH.OrderDate, COUNT(PRD.ProductID) AS [Total]
FROM Sales.SalesOrderHeader AS [SOH]
INNER JOIN Sales.SalesOrderDetail AS [SOD]
ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN Production.Product AS [PRD]
ON SOD.ProductID= PRD.ProductID
GROUP BY PRD.ProductID, SOH.OrderDate
ORDER BY SOH.OrderDate

/* 10. Display the 3rd joined employee. */
SELECT * FROM
(
	SELECT	HireDate, ROW_NUMBER()OVER(Order By HireDate DESC) AS [RN]
	FROM	HumanResources.Employee
	WHERE	YEAR(HireDate) = '2013'
)t WHERE RN = 3;

/* 11. Display the customer who has placed 2nd highest orders */
SELECT * FROM
(
SELECT CustomerID,COUNT(CustomerID) AS [NoOfOrders],
DENSE_RANK()OVER(ORDER BY COUNT(CustomerID) DESC) AS [Rank]
FROM Sales.SalesOrderHeader
GROUP BY CustomerID
)a
WHERE [Rank] = 2

/* 12. Display top 25% of costliest products in every subcategory */
SELECT * FROM
(
SELECT ProductID,Prod.ProductSubcategoryID,Prod.Name,StandardCost,
NTILE(4)OVER(PARTITION BY Prod.Name ORDER BY StandardCost DESC) AS [CostliestProduct]
FROM Production.Product AS [Pro]
JOIN
Production.ProductSubcategory AS [Prod]
ON Pro.ProductSubcategoryID = Prod.ProductSubcategoryID
)a
WHERE [CostliestProduct] = 1

/* 13. Create a sequence to be used in two different temporary tables (Note: create temporary tables if required) */
--Table 1
CREATE TABLE Customers
(
CustID INT,
CustName VARCHAR(20) NOT NULL
);


--Table 2
CREATE TABLE Employee
(
EmpID INT,
EmpName VARCHAR(20) NOT NULL
)

--Create Sequence
CREATE SEQUENCE seque AS INT
START WITH 101
INCREMENT BY 1
MAXVALUE 1000
MINVALUE 1    
SELECT NEXT VALUE FOR seque


--Insert the values
INSERT INTO Employee VALUES(NEXT VALUE FOR seque,'John')
--Display the values
SELECT * FROM Employee

--Insert the values
INSERT INTO Customers VALUES(NEXT VALUE FOR seque,'jerry')
--Display the values
SELECT * FROM Customers

