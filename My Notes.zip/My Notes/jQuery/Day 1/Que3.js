$(document).ready(function(){
    $("mydiv").hover(function(){
        window.open("https://www.google.com")
    });
});