$(document).ready(function(){
    $("#mydiv").on('click','#btn',function() {
        document.getElementById("sp").style.display = "block";
        let v = $('#email').val();
        $('#sp').html(v);
    });
});