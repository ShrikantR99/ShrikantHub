$(document).ready(function(){
    $("#button1").click(function(){
        $("textarea").addClass("sos")
    })
})
    $("#button2").click(function(){
        $("div1").html("Always respect each and everyone")
})
    $("#button3").click(function(){
        $("textarea").html("hellow")
    })