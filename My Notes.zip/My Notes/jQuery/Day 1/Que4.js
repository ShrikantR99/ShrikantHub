$(document).ready(function() {
    let s1 = $("input").val();
    $("input").focusout(function(){
        $("#ss").addClass("error")
    });
    let ss = $("input").val();
        if(ss.length > 10)
        {
            $("#ss").addClass("error")
        }
});