$(document).ready(function(){
    // $("#container").dialog({
    //     autoOpen:false,})

    $("#btn").on('click', function(){
        $("#container").css('display','block');
        $('#container').dialog();
    })
    $("#button").on('click', function(){
        $("#container").css('display','none');
    })
})

// $("#btn").on('click', function(){
//     $("#container").dialog();
    
// })