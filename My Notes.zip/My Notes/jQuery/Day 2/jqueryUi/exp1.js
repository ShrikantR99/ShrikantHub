$(document).ready(function(){
    $("#link1").attr('href','https://www.google.com/')
    $("#link2").attr('href','https://www.gmail.com/')
    $("#link3").attr('href','https://www.makemytrip.com/')
});