function loginButton(){
    let uname=document.getElementById(`username`).value;
    let pwd=document.getElementById(`password`).value;
    let invalidMsg=document.getElementById(`invalidMsg`);
    let invalidMsg1 =document.getElementById(`invalidMsg1`);
    

    if(uname == "citiustech" && pwd == "citiustech")
    {
        window.open(url="https://www.google.com" )
    }
    else {
         if(uname != "citiustech")
        {
            invalidMsg.textContent = "Invalid username";
            invalidMsg.style.color = "darkred";
        }
        else{
            document.getElementById('invalidMsg').textContent = '';
        }
        
        if (pwd != "citiustech") {
            invalidMsg1.textContent = "Invalid password";
            invalidMsg1.style.color = "darkred";
        }
        else{
            document.getElementById('invalidMsg1').textContent = '';
        }
}
}