//function to add new email-id text box
function addEmail(){
    let textbox = document.createElement("input");

//append textbox
    textbox.setAttribute("type","email");
    document.placeholder = "Enter your Email Id";
    document.body.appendChild(textbox);
    textbox.placeholder = "Enter Email Id";

//append the add new Email Button
    let removeEmailButton = document.createElement("input");
    removeEmailButton.setAttribute("type","button");
    removeEmailButton.value = "Remove Email";
    document.body.appendChild(removeEmailButton);

//function to remove the textbox and button
    removeEmailButton.onclick = function(){
        document.body.removeChild(textbox);
        document.body.removeChild(removeEmailButton);
    }
}