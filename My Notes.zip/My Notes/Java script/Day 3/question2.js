document.querySelector('#username').addEventListener('focusout',function(){
    let uname=document.getElementById('username').value;
    if(uname.length >0){
        document.getElementById("button").disabled = false;
    }
    
})



function loginButton(){
    let uname=document.getElementById(`username`).value;
    let pwd=document.getElementById(`password`).value;
    let invalidMsg=document.getElementById(`invalidMsg`);
    let invalidMsg1 =document.getElementById(`invalidMsg1`);
    

    if(uname.toLowerCase() == "citiustech" && pwd.toLowerCase() == "citiustech")
    {
        window.open(url="https://www.google.com" )
    }
    else {
         if(uname.toLowerCase() != "citiustech" || uname.indexof() ==' ')
        {
            invalidMsg.textContent = "Invalid username";
            invalidMsg.style.color = "darkred";
        }
        else{
            document.getElementById('invalidMsg').textContent = '';
        }
        
        if (pwd.toLowerCase() != "citiustech" || pwd.indexof() ==' ') {
            invalidMsg1.textContent = "Invalid password";
            invalidMsg1.style.color = "darkred";
        }
        else{
            document.getElementById('invalidMsg1').textContent = '';
        }
}
}