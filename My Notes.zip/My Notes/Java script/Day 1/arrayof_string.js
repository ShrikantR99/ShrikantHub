//JS code to create an array of 5 strings.
//Convert the last character of each string to uppercase and store the output in the same array.
//Print the final array.

arraystr = ['shrikant','rushikesh','prajwal','soham','ravi'];
function str1(array1)
{
    for(let i=0; i<array1.length; i++)
    {
        array1[i] = array1[i].slice(0,array1[i].length-1) + array1[i].slice(array1[i].length-1).toUpperCase();
    }
    console.log(array1);
}
str1(arraystr);