//JS code to determine how many digits are repeated in the number 7312140905.
function repeatedNum(n)
{
    var result = 0;
    var count = Array(10).fill(0);
    while(n > 0)
    {
        var remainder = n%10;
        count[remainder]++;
        n = Math.floor(n/10);
    }
    for(var i=0; i<10; i++)
    {
        if(count[i] > 1)
        {
            result++;
        }
    }
    return result;
}
var n=7312140905;
console.log(repeatedNum(n));