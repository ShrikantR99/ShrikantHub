let number=[1,2,3,4,5,6,7,8,9,10];
var sum = 0;
for(i = 0; i < number.length; i++)
{
    if(number[i] % 2 == 0)
    {
        sum += number[i];
    }
    
}
if(sum == 0)
    {
        console.log("No even number found");
    }
    else
    {
        console.log(`sum of even number in the given array is:${sum}`)
    }
    