//JS code to find the number of vowels in the string CITIUSTECH.
// If the vowel is repeated, it must be counted as 1.
string1 = 'CITIUSTECH';
function vowel(str)
{
    vowelstr = {'A':false,'E':false,'I':false,'O':false,'U':false}
    for(let i=0; i<str.length; i++)
    {
        if(str[i] in vowelstr)
        {
            vowelstr[str[i]] = true;
        }
    }
    count = 0;
    for(let k in vowelstr)
    {
        if(vowelstr[k] == true)
        {
            count = count+1;
        }
    }
    console.log(count);
}
vowel(string1);