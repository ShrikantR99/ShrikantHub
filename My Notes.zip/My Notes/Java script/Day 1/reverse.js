var rev = 0;
var num = 12345;
var lastnum;

while(num !=0)
{
    lastnum=num%10;
    rev=rev*10+lastnum;
    num=Math.floor(num/10);
}
console.log("reverse number:"+rev);