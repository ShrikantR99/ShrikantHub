var str = prompt("Enter the string to reverse:");
var reverse = " ";
var len;
var originalstr = str;
len = str.length;

for(var i=str.length-1; i>=0 ;i--)
{
    reverse = reverse + str[i];
}
console.log("the string is:"+originalstr);
console.log("the reversed string ids:"+reverse);