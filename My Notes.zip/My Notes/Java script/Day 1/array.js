var number1 = 0;
var number2 = 0;
var arr=[6,8,12,22,43,33,24,11,54,66];
var arraylength = arr.length;
var i;
for(i=0; i<arraylength; i++)
{
    if(arr[i] > number1)
    {
        number2=number1;
        number1=arr[i];
    }
    else
    {
        if(arr[i] > number2)
        {
            number2=arr[i];
        }
    }
}
console.log("First maximum number is:"+number1);
console.log("second maximum number is:"+number2);
