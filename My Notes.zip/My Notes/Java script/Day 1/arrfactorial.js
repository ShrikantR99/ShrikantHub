let arr = [2,3,4,5,6];
let factorialarr = [];
for(i of arr){
    let fact = 1;
    for(let j = 1; j<i; j++)
    {
        fact= fact * j;
    }
    factorialarr.push(fact);

}
console.log(`input array is:${arr}`)
console.log(`the array of factorial elements is:${factorialarr}`)