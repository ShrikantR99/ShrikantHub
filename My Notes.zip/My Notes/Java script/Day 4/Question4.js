function GetVideo() {
    return new Promise(function(resolve) {
    setTimeout(() => {
        resolve("Got Video")
    }, 3000);
});
}
function AddIntro() {
    return new Promise(function(resolve) {
    setTimeout(() => {
        resolve("Add intro")
    }, 3000);
});
}
function AddSummary() {
    return new Promise(function(resolve) {
    setTimeout(() => {
        resolve("Add Summary")
    }, 3000);
});
}
GetVideo().then((result) => {
    console.log(result);
});
AddIntro().then((result) => {
    console.log(result);
});
AddSummary().then((result) => {
    console.log(result);
});


// function GetVideo(){
//     return new Promise(() => {
//         setTimeout(() => {
//             console.log("Got video");
//         }, 3000)
//     })
// }
// function AddIntro(){
//     return new Promise((resolve) => {
//         setTimeout(() => {
//             console.log("Intro Added");
//         }, 3000)
//     })
// }
// function AddSummary(){
//     return new Promise((resolve) => {
//         setTimeout(() => {
//             console.log("Summary Added");
//         }, 3000)
//     })
// }
// GetVideo();
// AddIntro();
// AddSummary();