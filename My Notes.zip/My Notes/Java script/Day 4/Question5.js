//Rewrite the previous assignment  using async and await keywords.
async function myFunc(){
    function getVideo(){
        console.log("Got video");
    }
    function AddIntro(){
        return console.log("Intro Added");
    }
    function AddSummary(){
        return console.log("Summary Added");
    }
    getVideo();
    await AddIntro();
    AddSummary();
}
myFunc();
console.log("The await function checking...")