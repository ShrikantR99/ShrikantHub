function filterCondition(array,func){
    anotherArray =[];
    for(let i=0; i<array.length; i++){
        if(func(array[i])){
            anotherArray.push(array[i]);
        }
    }
    console.log(anotherArray);
}
array = [9,10,11,12,13,14,15,16,17,18];
console.log(`the array is: ${array}`);

console.log(`the odd numbers in the array is:`);
filterCondition(array,x => x % 2 != 0);

console.log(`the even numbers in the array is:`);
filterCondition(array,x => x % 2 == 0);

console.log(`the prime numbers in the array is:`);
filterCondition(array, x => { 
    if(x <= 1){
        return false
    }
    for(let i=2; i<x; i++){
        if(x % i == 0) {
            return false
        }
    }
    return true
})
