// var nums = [1,2,34,54,55,34,32,11,19,17,54,66,13];
// var evens = [];
// var odds = [];

// var evenNumbers = function(nums) {
//     for (var i = 0; i < nums.length; i++) {

//         if ((nums[i] % 2) != 1) {
//             evens.push(nums[i]);
//                 console.log(evens);
//         }
//         else {
//             odds.push(nums[i]);
//                 console.log(odds);
//         }
//     }

// };

// alert(evens);
// alert(odds);

const numbers = [7, 10, 15, 8, 13, 18, 6];

const evens = numbers.filter((num) => num % 2 === 0);

const odds = numbers.filter((num) => num % 2 === 1);

// [10, 8, 18, 6]

console.log(evens);

console.log(odds);