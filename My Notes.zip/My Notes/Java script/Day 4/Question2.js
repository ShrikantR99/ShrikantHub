//Write a JS function which accepts an array of 10 numbers.
//The function must return another array which contains only the odd numbers in the source array.
function Func(){
    let array = [9,10,11,12,13,14,15,16,17,18];
    let anotherArray = [];
        for(let i=0; i<array.length; i++)
        {
            if(array[i] % 2!=0)
            {
                anotherArray.push(array[i]);
            }
        }
console.log(anotherArray);
}
Func();