function Add() {
    fetch('https://jsonplaceholder.typicode.com/posts/1',{
        method: 'PUT',
        body:JSON.stringify({
            userId:1,
            name:document.getElementById('Name').value,
            Username:document.getElementById('username').value,
            email:document.getElementById('email').value,
        }),
        headers:{
            'Content-type': 'application/json; charset=UTF-8',
        },
    })
    .then((response) => response.json())
    .then((json) => console.log(json));
}