function enter(){
    let x = document.getElementById("txtbox").value;
    fetch('https://jsonplaceholder.typicode.com/users')
    .then((response) => {
        return response.json();
    })
    .then((json) => {
        document.writeln(`id: ${json[x-1].id} | name: ${json[x-1].name}`)
    })
}