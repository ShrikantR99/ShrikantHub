function newData(){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            document.getElementById('sample').innerHTML = this.responseText;
        }
    };
    xhr.open("GET", "file.json", true);
    xhr.send();
}