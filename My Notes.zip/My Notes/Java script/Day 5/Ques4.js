document.getElementById("btn").addEventListener('click',function(){
    fetch('https://jsonplaceholder.typicode.com/posts',{
        method: 'POST',
        body:JSON.stringify({
            userId:document.getElementById('txtbox').value,
            name:document.getElementById('name').value,
            UserName:document.getElementById('username').value,
            emailId:document.getElementById('txtbox').value,
        }),
        headers:{
            'Content-type': 'application/json; charset=UTF-8',
        },
    })
    .then((response) => response.json())
    .then((json) => console.log(json));
})