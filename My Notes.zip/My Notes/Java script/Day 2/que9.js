//JS function which takes 3 arguments, namely arg1, arg2 and arg3. Call the function by passing an array of 3 elements to it. 
//The function must return the maximum value from the array passed to it.
function maxval(arg1, arg2, arg3){
    if(arg1>arg2 && arg1>arg3){
        console.log(`${arg1} is the maximum number`);
    }
    else if(arg2>arg1 && arg2>arg3){
        console.log(`${arg2} is the maximum number`);
    }
    else{
        console.log(`${arg3} is maximum number`);
    }
}
let array = [22,65,43];
maxval(...array)