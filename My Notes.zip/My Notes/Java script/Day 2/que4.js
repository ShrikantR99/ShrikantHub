//JS arrow function named Login() which takes a username and password. 
//In case any of the arguments or both are not passed, the default values must be CT and CT respectively.
const login = (username = "CT", password = "CT") => {
    console.log("username is:" +username);
    console.log("password is:" +password);
}
login()
login("shrikant")
login(undefined, "4321")
login("shrikant","4321")