//function using calculate the factorial of number
function factorial(num)
{
    let fact = 1;
    //initilization of for statement
    for(let i = num; i>1; i--)
    {
        fact = fact * i;
    }
    //return factorial
    return fact;
}
let f = factorial(4);
console.log(f);