function sumofNumber(...arg){
    let sum = 0;
    if(arguments.length == 0)
    {
        console.log("the number of arguments is zero");
    }
    for(let i=0; i<arguments.length; i++)
    {
        sum = sum + arguments[i];
    }
    return sum;
}
let n = sumofNumber(10,20);
console.log(n);