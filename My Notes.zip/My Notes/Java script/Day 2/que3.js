//JS function which takes variable number of arguments
// and prints each argument on the screen and also the number of arguments passed.
function number(){
    let number=0;
    console.log("the number of arguments are passed: " +arguments.length);

    for(let i=0; i<=arguments.length-1; i++)
    {
        console.log(arguments[i])
    }
    return number;

}
number(2,3,4);