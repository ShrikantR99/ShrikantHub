//Rewrite the function created in assignment 1 as an arrow function
//JS function which takes a number as an argument and returns its factorial
const factorial = (num) => {
    let fact = 1;
    for(let i=1; i<=num; i++){
        fact *= i;
    }console.log(fact);
}
factorial(4);