//Pass the object created in assignment 5 to an arrow function. 
//The function must return a string which contains the vehicleid, brand, ,model, variant & speed.
const specifics = {
    firstGear: function(){
        return `this is first gear`;
    },
    secondGear: function(){
        return `this is second gear`;
    },
    maxSpeed: 125,
    changegear: function(){
         return `first gear: ${this.firstGear()}, second gear: ${this.secondGear()}`
    }
};

vehicle = {
    vehicleId: 1343556,
    brand: `BMW`,
    model: `bmw x1`,
    varient: `bs221`,
    specifications: specifics
}

let gear = (car) => {
    console.log(`The vehicleId is: ${vehicle.vehicleId}`);
    console.log(`The brand is: ${vehicle.brand}`);
    console.log(`The model is: ${vehicle.model}`);
    console.log(`The varient is: ${vehicle.varient}`);
    console.log(`The maximum speed is: ${vehicle.specifications.maxSpeed}`);
}

gear(vehicle);