//Arrow function using sum of two number.
const sumOfTwoNum = (num1,num2) => {
   //calculate the sum
    sum = num1 + num2;
   //return the sum value
    return sum;
}
console.log(sumOfTwoNum(22,10))
