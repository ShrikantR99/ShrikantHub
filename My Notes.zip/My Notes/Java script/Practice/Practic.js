//average
function avg(x, y) {
    return (x + y) / 2

}
let a = 2;
let b = 3;
let c = 4;

console.log("average numbers", avg(a, b));
console.log("average numbers", avg(b, c));
console.log("average numbers", avg(a, c));


//reverse string
const str= "shrikant";

const rev=str.split('').reverse('').join('');
console.log(rev)

//// CONVERT STRING IN REVERSE ORDER
/*
1.convert the string into array
2.reverse the arrat
3.join the array into string */

const st = (str) =>
{
    let arr = str.split(""); // SPLIT method converts string into array
    arr.reverse();
    str = arr.join("");//join method combine the array element into one string 
    console.log(str);
}

st("Ravalukedari");

const string= (str) =>
{
    let array = str.split('');
    array.reverse('');
    str=array.join('');
    console.log(str)
}
string('Shrikant')




// PALIDROME 
/*
1.convert the string into array by using the split.reverse.join.
2. check whether the original string is same.
 */
//Ex1
const sss = (str) =>
{
    const isPalidrome = str.split("").reverse().join('');
    console.log(str == isPalidrome);
}

sss("abba");

//Ex2
const pal=(str) =>
{
    const isPalidrome=str.split('').reverse('').join('');
    console.log(str==isPalidrome);
}

pal('gadaaa')
// /*
// Find the maximun character  in the string and how many times it appears

// 1. create an obj , means key value pair
// 2.if character is not  present in the obj then set the value = 1 , if exist then increment the value 
// */

const ssp =(str)=>
{
    let obj = {};
    for(let p of str)
    
        (!obj[p])? obj[p]= 1: obj[p]++;
        
    let maxNumber = 0;
    let minChar = '';
    for (let p of str)
    {
        if( obj[p] >= maxNumber )
        {
            maxNumber = obj[p];
            minChar = p;
        }

    }
    console.log(`${minChar} appears ${maxNumber} times`);
}

ssp("saasss");

// /* 
//  convert the integer in reverse order

//  Steps
//  1.convert the int. into strig
//  2.convert the string into array
//  3.Reverse the array
//  4. reverse back to string 
//  reverse back to int
//  */

const revInt = (n)=>{
    return parseInt(n.toString().split('').reverse().join(''))
}
console.log(revInt(12345));

// /*
// FizzBuzz
// if number is multiple of 3 the print fizz , 
// if multiple of 5 print buzz and the number is multiple of both 3 and 5 then print fizzbuzz.
// */

const srk =(n)=>{

for (let i = 1;i<=15;i++)
{
    //check for 3 and 5
    if(i%3 ===0 && i%5===0 )
    {
    console.log("FizzBuzz");
    i++;
    }
    //check for 3
    
    if(i%3 ===0 )
    {

        console.log("Fizz")
        i++;
    }

    //check for 5
    
    if(i%5===0 )
    {

        console.log("Buzz")
        i++;
    }

//     // Agaim check for 3 because when the number is 5 this condition is fail for 3 but true for 5 but at the last
//     //we increment the value for that value i.e 6 we again check for the 3

//     // again check for the 3
    if(i%3 ===0  )
    {

        console.log("Fizz")
        i++;
    }

//     //else 
//     // in this condition eg. our number is 15 in that condition we increment the value  but our last limit is 15 to 
//     //break that statement we use this condition

    if(i>n)
    break;
    else
    console.log(i);
}

}
srk(100);


// // /*
// // Is Unique element is present 

// // */

const shri = (str) =>
{   
    let obj = {};
    for(let ss of str)
    (!obj[ss])? obj[ss] = 1:obj[ss]++;

    for(let ss in obj)
    {
    
    if(obj[ss]>1)
    return false;
    }
    
      
    return true;
    
    
}   

console.log({
    isunique:shri('Shrikant')
})



function demo(){

    const st=new prompt((resolve,reject)=>{
        setTimeout(()=>{

        },2000)
    })
}
console.log(st);